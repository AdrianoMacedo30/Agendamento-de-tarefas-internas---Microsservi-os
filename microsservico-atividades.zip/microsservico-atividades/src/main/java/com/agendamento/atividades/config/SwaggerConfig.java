package com.agendamento.atividades.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Microsserviço de Atividades")
                        .version("1.0.0")
                        .description("""
                                API REST para gerenciamento de atividades/tarefas internas. Porta: 8082
                                
                                ⚠️ Este serviço consulta o Microsserviço de Funcionários (porta 8081)
                                antes de cadastrar ou atualizar qualquer atividade.
                                """)
                        .contact(new Contact()
                                .name("Sistema de Agendamento de Tarefas")
                                .email("contato@agendamento.com")));
    }
}

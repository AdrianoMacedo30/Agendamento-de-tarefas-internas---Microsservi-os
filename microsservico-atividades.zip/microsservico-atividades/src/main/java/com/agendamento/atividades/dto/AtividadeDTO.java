package com.agendamento.atividades.dto;

import com.agendamento.atividades.model.Atividade;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

public class AtividadeDTO {

    private Long id;

    @NotBlank(message = "Título é obrigatório")
    @Size(min = 3, max = 150, message = "Título deve ter entre 3 e 150 caracteres")
    private String titulo;

    @NotBlank(message = "Descrição é obrigatória")
    private String descricao;

    @NotNull(message = "Data de início é obrigatória")
    private LocalDate dataInicio;

    @NotNull(message = "Data de prazo é obrigatória")
    private LocalDate dataPrazo;

    private Atividade.StatusAtividade status;

    @NotNull(message = "Prioridade é obrigatória")
    private Atividade.Prioridade prioridade;

    @NotNull(message = "ID do funcionário é obrigatório")
    private Long funcionarioId;

    private String nomeFuncionario;
    private String cargoFuncionario;

    public AtividadeDTO() {}

    public static AtividadeDTO fromEntity(Atividade a) {
        AtividadeDTO dto = new AtividadeDTO();
        dto.setId(a.getId());
        dto.setTitulo(a.getTitulo());
        dto.setDescricao(a.getDescricao());
        dto.setDataInicio(a.getDataInicio());
        dto.setDataPrazo(a.getDataPrazo());
        dto.setStatus(a.getStatus());
        dto.setPrioridade(a.getPrioridade());
        dto.setFuncionarioId(a.getFuncionarioId());
        dto.setNomeFuncionario(a.getNomeFuncionario());
        dto.setCargoFuncionario(a.getCargoFuncionario());
        return dto;
    }

    public Atividade toEntity() {
        Atividade a = new Atividade();
        a.setId(this.id);
        a.setTitulo(this.titulo);
        a.setDescricao(this.descricao);
        a.setDataInicio(this.dataInicio);
        a.setDataPrazo(this.dataPrazo);
        a.setStatus(this.status != null ? this.status : Atividade.StatusAtividade.PENDENTE);
        a.setPrioridade(this.prioridade);
        a.setFuncionarioId(this.funcionarioId);
        a.setNomeFuncionario(this.nomeFuncionario);
        a.setCargoFuncionario(this.cargoFuncionario);
        return a;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }

    public LocalDate getDataPrazo() { return dataPrazo; }
    public void setDataPrazo(LocalDate dataPrazo) { this.dataPrazo = dataPrazo; }

    public Atividade.StatusAtividade getStatus() { return status; }
    public void setStatus(Atividade.StatusAtividade status) { this.status = status; }

    public Atividade.Prioridade getPrioridade() { return prioridade; }
    public void setPrioridade(Atividade.Prioridade prioridade) { this.prioridade = prioridade; }

    public Long getFuncionarioId() { return funcionarioId; }
    public void setFuncionarioId(Long funcionarioId) { this.funcionarioId = funcionarioId; }

    public String getNomeFuncionario() { return nomeFuncionario; }
    public void setNomeFuncionario(String nomeFuncionario) { this.nomeFuncionario = nomeFuncionario; }

    public String getCargoFuncionario() { return cargoFuncionario; }
    public void setCargoFuncionario(String cargoFuncionario) { this.cargoFuncionario = cargoFuncionario; }
}

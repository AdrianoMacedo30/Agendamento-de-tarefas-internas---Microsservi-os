package com.agendamento.atividades.config;

import com.agendamento.atividades.model.Atividade;
import com.agendamento.atividades.repository.AtividadeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final AtividadeRepository repository;

    public DataInitializer(AtividadeRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() == 0) {
            Atividade a1 = new Atividade();
            a1.setTitulo("Implementar módulo de relatórios");
            a1.setDescricao("Desenvolver o módulo de geração de relatórios mensais em PDF.");
            a1.setDataInicio(LocalDate.now());
            a1.setDataPrazo(LocalDate.now().plusDays(15));
            a1.setStatus(Atividade.StatusAtividade.PENDENTE);
            a1.setPrioridade(Atividade.Prioridade.ALTA);
            a1.setFuncionarioId(1L);
            a1.setNomeFuncionario("Ana Souza");
            a1.setCargoFuncionario("Desenvolvedora");
            repository.save(a1);

            Atividade a2 = new Atividade();
            a2.setTitulo("Revisar fluxo de caixa Q3");
            a2.setDescricao("Analisar e validar os lançamentos do terceiro trimestre.");
            a2.setDataInicio(LocalDate.now());
            a2.setDataPrazo(LocalDate.now().plusDays(7));
            a2.setStatus(Atividade.StatusAtividade.EM_ANDAMENTO);
            a2.setPrioridade(Atividade.Prioridade.CRITICA);
            a2.setFuncionarioId(2L);
            a2.setNomeFuncionario("Carlos Lima");
            a2.setCargoFuncionario("Analista");
            repository.save(a2);

            System.out.println("Dados iniciais de atividades carregados.");
        }
    }
}

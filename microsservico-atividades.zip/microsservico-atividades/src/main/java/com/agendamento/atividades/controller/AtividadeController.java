package com.agendamento.atividades.controller;

import com.agendamento.atividades.dto.AtividadeDTO;
import com.agendamento.atividades.model.Atividade;
import com.agendamento.atividades.service.AtividadeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/atividades")
@Tag(name = "Atividades", description = "API de gerenciamento de atividades/tarefas internas")
public class AtividadeController {

    private final AtividadeService service;

    public AtividadeController(AtividadeService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Listar todas as atividades",
               description = "Retorna todas as atividades. Filtre por status ou funcionário usando os parâmetros.")
    public ResponseEntity<List<AtividadeDTO>> listarTodas(
            @RequestParam(required = false) Atividade.StatusAtividade status,
            @RequestParam(required = false) Long funcionarioId) {

        if (funcionarioId != null) {
            return ResponseEntity.ok(service.listarPorFuncionario(funcionarioId));
        }
        if (status != null) {
            return ResponseEntity.ok(service.listarPorStatus(status));
        }
        return ResponseEntity.ok(service.listarTodas());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar atividade por ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Atividade encontrada"),
        @ApiResponse(responseCode = "404", description = "Atividade não encontrada")
    })
    public ResponseEntity<AtividadeDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    @PostMapping
    @Operation(summary = "Criar nova atividade",
               description = "Cria uma atividade verificando se o funcionário responsável existe no microsserviço de funcionários.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Atividade criada com sucesso"),
        @ApiResponse(responseCode = "400", description = "Dados inválidos"),
        @ApiResponse(responseCode = "422", description = "Funcionário não encontrado no microsserviço"),
        @ApiResponse(responseCode = "409", description = "Violação de regra de negócio"),
        @ApiResponse(responseCode = "503", description = "Microsserviço de funcionários indisponível")
    })
    public ResponseEntity<AtividadeDTO> criar(@Valid @RequestBody AtividadeDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.criar(dto));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualizar atividade existente")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Atividade atualizada"),
        @ApiResponse(responseCode = "404", description = "Atividade não encontrada"),
        @ApiResponse(responseCode = "409", description = "Violação de regra de negócio")
    })
    public ResponseEntity<AtividadeDTO> atualizar(
            @PathVariable Long id,
            @Valid @RequestBody AtividadeDTO dto) {
        return ResponseEntity.ok(service.atualizar(id, dto));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Atualizar apenas o status de uma atividade")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Status atualizado"),
        @ApiResponse(responseCode = "404", description = "Atividade não encontrada"),
        @ApiResponse(responseCode = "409", description = "Transição de status inválida")
    })
    public ResponseEntity<AtividadeDTO> atualizarStatus(
            @PathVariable Long id,
            @Parameter(description = "Novo status: PENDENTE, EM_ANDAMENTO, CONCLUIDA, CANCELADA")
            @RequestParam Atividade.StatusAtividade status) {
        return ResponseEntity.ok(service.atualizarStatus(id, status));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Remover atividade")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Atividade removida"),
        @ApiResponse(responseCode = "404", description = "Atividade não encontrada")
    })
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        service.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

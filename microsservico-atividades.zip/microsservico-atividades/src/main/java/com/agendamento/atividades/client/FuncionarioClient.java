package com.agendamento.atividades.client;

import com.agendamento.atividades.dto.FuncionarioResponseDTO;
import com.agendamento.atividades.exception.FuncionarioNotFoundException;
import com.agendamento.atividades.exception.ServiceUnavailableException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

@Component
public class FuncionarioClient {

    private final RestTemplate restTemplate;
    private final String funcionariosUrl;

    public FuncionarioClient(RestTemplate restTemplate,
                             @Value("${funcionarios.service.url}") String funcionariosUrl) {
        this.restTemplate = restTemplate;
        this.funcionariosUrl = funcionariosUrl;
    }

    public FuncionarioResponseDTO buscarFuncionario(Long funcionarioId) {
        String url = funcionariosUrl + "/funcionarios/" + funcionarioId;
        System.out.println("Consultando microsserviço de funcionários: GET " + url);

        try {
            FuncionarioResponseDTO funcionario = restTemplate.getForObject(url, FuncionarioResponseDTO.class);

            if (funcionario == null) {
                throw new FuncionarioNotFoundException(
                        "Funcionário com ID " + funcionarioId + " não encontrado.");
            }

            System.out.println("Funcionário encontrado: " + funcionario.getId() + " - " + funcionario.getNome());
            return funcionario;

        } catch (HttpClientErrorException.NotFound e) {
            throw new FuncionarioNotFoundException(
                    "Funcionário com ID " + funcionarioId + " não existe no sistema.");

        } catch (ResourceAccessException e) {
            throw new ServiceUnavailableException(
                    "Microsserviço de funcionários está indisponível. Tente novamente mais tarde.");
        }
    }

    public boolean funcionarioEstaAtivo(Long funcionarioId) {
        FuncionarioResponseDTO f = buscarFuncionario(funcionarioId);
        return "ATIVO".equals(f.getStatus());
    }
}

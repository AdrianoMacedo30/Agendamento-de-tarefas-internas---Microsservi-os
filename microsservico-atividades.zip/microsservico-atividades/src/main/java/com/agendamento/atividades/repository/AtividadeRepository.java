package com.agendamento.atividades.repository;

import com.agendamento.atividades.model.Atividade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AtividadeRepository extends JpaRepository<Atividade, Long> {

    List<Atividade> findByFuncionarioId(Long funcionarioId);

    List<Atividade> findByStatus(Atividade.StatusAtividade status);

    List<Atividade> findByPrioridade(Atividade.Prioridade prioridade);
}

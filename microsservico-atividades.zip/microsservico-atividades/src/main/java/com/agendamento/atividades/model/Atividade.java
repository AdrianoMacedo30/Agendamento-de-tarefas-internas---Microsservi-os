package com.agendamento.atividades.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "atividades")
public class Atividade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Título é obrigatório")
    @Size(min = 3, max = 150, message = "Título deve ter entre 3 e 150 caracteres")
    @Column(nullable = false)
    private String titulo;

    @NotBlank(message = "Descrição é obrigatória")
    @Column(nullable = false, length = 1000)
    private String descricao;

    @NotNull(message = "Data de início é obrigatória")
    @Column(nullable = false)
    private LocalDate dataInicio;

    @NotNull(message = "Data de prazo é obrigatória")
    @Column(nullable = false)
    private LocalDate dataPrazo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private StatusAtividade status;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Prioridade prioridade;

    @NotNull(message = "ID do funcionário responsável é obrigatório")
    @Column(nullable = false)
    private Long funcionarioId;

    @Column
    private String nomeFuncionario;

    @Column
    private String cargoFuncionario;

    public enum StatusAtividade {
        PENDENTE, EM_ANDAMENTO, CONCLUIDA, CANCELADA
    }

    public enum Prioridade {
        BAIXA, MEDIA, ALTA, CRITICA
    }

    public Atividade() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }

    public LocalDate getDataPrazo() { return dataPrazo; }
    public void setDataPrazo(LocalDate dataPrazo) { this.dataPrazo = dataPrazo; }

    public StatusAtividade getStatus() { return status; }
    public void setStatus(StatusAtividade status) { this.status = status; }

    public Prioridade getPrioridade() { return prioridade; }
    public void setPrioridade(Prioridade prioridade) { this.prioridade = prioridade; }

    public Long getFuncionarioId() { return funcionarioId; }
    public void setFuncionarioId(Long funcionarioId) { this.funcionarioId = funcionarioId; }

    public String getNomeFuncionario() { return nomeFuncionario; }
    public void setNomeFuncionario(String nomeFuncionario) { this.nomeFuncionario = nomeFuncionario; }

    public String getCargoFuncionario() { return cargoFuncionario; }
    public void setCargoFuncionario(String cargoFuncionario) { this.cargoFuncionario = cargoFuncionario; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Long id;
        private String titulo, descricao, nomeFuncionario, cargoFuncionario;
        private LocalDate dataInicio, dataPrazo;
        private StatusAtividade status;
        private Prioridade prioridade;
        private Long funcionarioId;

        public Builder id(Long id) { this.id = id; return this; }
        public Builder titulo(String titulo) { this.titulo = titulo; return this; }
        public Builder descricao(String descricao) { this.descricao = descricao; return this; }
        public Builder dataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; return this; }
        public Builder dataPrazo(LocalDate dataPrazo) { this.dataPrazo = dataPrazo; return this; }
        public Builder status(StatusAtividade status) { this.status = status; return this; }
        public Builder prioridade(Prioridade prioridade) { this.prioridade = prioridade; return this; }
        public Builder funcionarioId(Long funcionarioId) { this.funcionarioId = funcionarioId; return this; }
        public Builder nomeFuncionario(String nomeFuncionario) { this.nomeFuncionario = nomeFuncionario; return this; }
        public Builder cargoFuncionario(String cargoFuncionario) { this.cargoFuncionario = cargoFuncionario; return this; }

        public Atividade build() {
            Atividade a = new Atividade();
            a.id = this.id;
            a.titulo = this.titulo;
            a.descricao = this.descricao;
            a.dataInicio = this.dataInicio;
            a.dataPrazo = this.dataPrazo;
            a.status = this.status;
            a.prioridade = this.prioridade;
            a.funcionarioId = this.funcionarioId;
            a.nomeFuncionario = this.nomeFuncionario;
            a.cargoFuncionario = this.cargoFuncionario;
            return a;
        }
    }
}

package com.agendamento.atividades.service;

import com.agendamento.atividades.client.FuncionarioClient;
import com.agendamento.atividades.dto.AtividadeDTO;
import com.agendamento.atividades.dto.FuncionarioResponseDTO;
import com.agendamento.atividades.exception.BusinessException;
import com.agendamento.atividades.exception.ResourceNotFoundException;
import com.agendamento.atividades.model.Atividade;
import com.agendamento.atividades.repository.AtividadeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AtividadeService {

    private final AtividadeRepository repository;
    private final FuncionarioClient funcionarioClient;

    public AtividadeService(AtividadeRepository repository, FuncionarioClient funcionarioClient) {
        this.repository = repository;
        this.funcionarioClient = funcionarioClient;
    }

    public List<AtividadeDTO> listarTodas() {
        return repository.findAll().stream().map(AtividadeDTO::fromEntity).collect(Collectors.toList());
    }

    public AtividadeDTO buscarPorId(Long id) {
        Atividade a = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Atividade não encontrada com id: " + id));
        return AtividadeDTO.fromEntity(a);
    }

    public List<AtividadeDTO> listarPorFuncionario(Long funcionarioId) {
        funcionarioClient.buscarFuncionario(funcionarioId);
        return repository.findByFuncionarioId(funcionarioId).stream()
                .map(AtividadeDTO::fromEntity).collect(Collectors.toList());
    }

    public List<AtividadeDTO> listarPorStatus(Atividade.StatusAtividade status) {
        return repository.findByStatus(status).stream()
                .map(AtividadeDTO::fromEntity).collect(Collectors.toList());
    }

    public AtividadeDTO criar(AtividadeDTO dto) {
        System.out.println("Verificando funcionário ID " + dto.getFuncionarioId() + " no microsserviço de funcionários...");
        FuncionarioResponseDTO funcionario = funcionarioClient.buscarFuncionario(dto.getFuncionarioId());

        if (!"ATIVO".equals(funcionario.getStatus())) {
            throw new BusinessException(
                    "Não é possível atribuir atividade ao funcionário '" + funcionario.getNome() +
                    "' pois seu status é: " + funcionario.getStatus() +
                    ". Apenas funcionários ATIVOS podem receber novas tarefas.");
        }

        if (dto.getDataPrazo().isBefore(dto.getDataInicio())) {
            throw new BusinessException("A data de prazo não pode ser anterior à data de início.");
        }

        if (dto.getDataInicio().isBefore(LocalDate.now())) {
            throw new BusinessException("A data de início não pode ser no passado.");
        }

        Atividade atividade = dto.toEntity();
        atividade.setNomeFuncionario(funcionario.getNome());
        atividade.setCargoFuncionario(funcionario.getCargo());
        atividade.setStatus(Atividade.StatusAtividade.PENDENTE);

        System.out.println("Criando atividade '" + dto.getTitulo() + "' para funcionário '" + funcionario.getNome() + "'");
        return AtividadeDTO.fromEntity(repository.save(atividade));
    }

    public AtividadeDTO atualizar(Long id, AtividadeDTO dto) {
        Atividade existente = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Atividade não encontrada com id: " + id));

        if (existente.getStatus() == Atividade.StatusAtividade.CANCELADA) {
            throw new BusinessException("Não é possível alterar uma atividade cancelada.");
        }

        if (!existente.getFuncionarioId().equals(dto.getFuncionarioId())) {
            FuncionarioResponseDTO novoFuncionario = funcionarioClient.buscarFuncionario(dto.getFuncionarioId());
            if (!"ATIVO".equals(novoFuncionario.getStatus())) {
                throw new BusinessException("Funcionário '" + novoFuncionario.getNome() + "' não está ATIVO.");
            }
            existente.setFuncionarioId(novoFuncionario.getId());
            existente.setNomeFuncionario(novoFuncionario.getNome());
            existente.setCargoFuncionario(novoFuncionario.getCargo());
        }

        if (dto.getDataPrazo().isBefore(dto.getDataInicio())) {
            throw new BusinessException("A data de prazo não pode ser anterior à data de início.");
        }

        existente.setTitulo(dto.getTitulo());
        existente.setDescricao(dto.getDescricao());
        existente.setDataInicio(dto.getDataInicio());
        existente.setDataPrazo(dto.getDataPrazo());
        existente.setPrioridade(dto.getPrioridade());
        if (dto.getStatus() != null) {
            existente.setStatus(dto.getStatus());
        }

        return AtividadeDTO.fromEntity(repository.save(existente));
    }

    public AtividadeDTO atualizarStatus(Long id, Atividade.StatusAtividade novoStatus) {
        Atividade existente = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Atividade não encontrada com id: " + id));

        if (existente.getStatus() == Atividade.StatusAtividade.CONCLUIDA
                && novoStatus != Atividade.StatusAtividade.CANCELADA) {
            throw new BusinessException("Uma atividade concluída só pode ser cancelada.");
        }

        existente.setStatus(novoStatus);
        return AtividadeDTO.fromEntity(repository.save(existente));
    }

    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Atividade não encontrada com id: " + id);
        }
        repository.deleteById(id);
    }
}

package com.agendamento.funcionarios.service;

import com.agendamento.funcionarios.dto.FuncionarioDTO;
import com.agendamento.funcionarios.exception.BusinessException;
import com.agendamento.funcionarios.exception.ResourceNotFoundException;
import com.agendamento.funcionarios.model.Funcionario;
import com.agendamento.funcionarios.repository.FuncionarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FuncionarioService {

    private final FuncionarioRepository repository;

    public FuncionarioService(FuncionarioRepository repository) {
        this.repository = repository;
    }

    public List<FuncionarioDTO> listarTodos() {
        return repository.findAll().stream().map(FuncionarioDTO::fromEntity).collect(Collectors.toList());
    }

    public FuncionarioDTO buscarPorId(Long id) {
        Funcionario f = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Funcionário não encontrado com id: " + id));
        return FuncionarioDTO.fromEntity(f);
    }

    public FuncionarioDTO criar(FuncionarioDTO dto) {
        if (repository.existsByEmail(dto.getEmail())) {
            throw new BusinessException("Já existe um funcionário com o e-mail: " + dto.getEmail());
        }
        if (repository.existsByCpf(dto.getCpf())) {
            throw new BusinessException("Já existe um funcionário com o CPF: " + dto.getCpf());
        }
        Funcionario funcionario = dto.toEntity();
        if (funcionario.getStatus() == null) {
            funcionario.setStatus(Funcionario.StatusFuncionario.ATIVO);
        }
        return FuncionarioDTO.fromEntity(repository.save(funcionario));
    }

    public FuncionarioDTO atualizar(Long id, FuncionarioDTO dto) {
        Funcionario existente = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Funcionário não encontrado com id: " + id));

        repository.findByEmail(dto.getEmail()).ifPresent(f -> {
            if (!f.getId().equals(id)) {
                throw new BusinessException("E-mail já está em uso por outro funcionário.");
            }
        });

        repository.findByCpf(dto.getCpf()).ifPresent(f -> {
            if (!f.getId().equals(id)) {
                throw new BusinessException("CPF já está em uso por outro funcionário.");
            }
        });

        existente.setNome(dto.getNome());
        existente.setEmail(dto.getEmail());
        existente.setCargo(dto.getCargo());
        existente.setDepartamento(dto.getDepartamento());
        existente.setCpf(dto.getCpf());
        if (dto.getStatus() != null) {
            existente.setStatus(dto.getStatus());
        }
        return FuncionarioDTO.fromEntity(repository.save(existente));
    }

    public void deletar(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Funcionário não encontrado com id: " + id);
        }
        repository.deleteById(id);
    }

    public boolean existePorId(Long id) {
        return repository.existsById(id);
    }
}

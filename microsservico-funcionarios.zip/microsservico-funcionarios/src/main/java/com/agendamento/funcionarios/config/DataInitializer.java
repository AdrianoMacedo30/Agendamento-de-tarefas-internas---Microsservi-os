package com.agendamento.funcionarios.config;

import com.agendamento.funcionarios.model.Funcionario;
import com.agendamento.funcionarios.repository.FuncionarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final FuncionarioRepository repository;

    public DataInitializer(FuncionarioRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        if (repository.count() == 0) {
            Funcionario f1 = new Funcionario();
            f1.setNome("Ana Souza");
            f1.setEmail("ana.souza@empresa.com");
            f1.setCargo("Desenvolvedora");
            f1.setDepartamento("TI");
            f1.setCpf("12345678901");
            f1.setStatus(Funcionario.StatusFuncionario.ATIVO);
            repository.save(f1);

            Funcionario f2 = new Funcionario();
            f2.setNome("Carlos Lima");
            f2.setEmail("carlos.lima@empresa.com");
            f2.setCargo("Analista");
            f2.setDepartamento("Financeiro");
            f2.setCpf("98765432100");
            f2.setStatus(Funcionario.StatusFuncionario.ATIVO);
            repository.save(f2);

            Funcionario f3 = new Funcionario();
            f3.setNome("Mariana Costa");
            f3.setEmail("mariana.costa@empresa.com");
            f3.setCargo("Gerente");
            f3.setDepartamento("RH");
            f3.setCpf("11122233344");
            f3.setStatus(Funcionario.StatusFuncionario.FERIAS);
            repository.save(f3);

            System.out.println("Dados iniciais de funcionários carregados.");
        }
    }
}

package com.agendamento.funcionarios.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Microsserviço de Funcionários")
                        .version("1.0.0")
                        .description("API REST para gerenciamento de funcionários. Porta: 8081")
                        .contact(new Contact()
                                .name("Sistema de Agendamento de Tarefas")
                                .email("contato@agendamento.com")));
    }
}

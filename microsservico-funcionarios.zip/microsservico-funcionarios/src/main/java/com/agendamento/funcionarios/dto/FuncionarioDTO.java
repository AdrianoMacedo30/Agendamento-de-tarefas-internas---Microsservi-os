package com.agendamento.funcionarios.dto;

import com.agendamento.funcionarios.model.Funcionario;
import jakarta.validation.constraints.*;

public class FuncionarioDTO {

    private Long id;

    @NotBlank(message = "Nome é obrigatório")
    @Size(min = 2, max = 100, message = "Nome deve ter entre 2 e 100 caracteres")
    private String nome;

    @NotBlank(message = "E-mail é obrigatório")
    @Email(message = "E-mail inválido")
    private String email;

    @NotBlank(message = "Cargo é obrigatório")
    private String cargo;

    @NotBlank(message = "Departamento é obrigatório")
    private String departamento;

    @NotBlank(message = "CPF é obrigatório")
    @Pattern(regexp = "\\d{11}", message = "CPF deve conter 11 dígitos numéricos")
    private String cpf;

    private Funcionario.StatusFuncionario status;

    public FuncionarioDTO() {}

    public FuncionarioDTO(Long id, String nome, String email, String cargo, String departamento, String cpf, Funcionario.StatusFuncionario status) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.cargo = cargo;
        this.departamento = departamento;
        this.cpf = cpf;
        this.status = status;
    }

    public static FuncionarioDTO fromEntity(Funcionario f) {
        return new FuncionarioDTO(f.getId(), f.getNome(), f.getEmail(), f.getCargo(), f.getDepartamento(), f.getCpf(), f.getStatus());
    }

    public Funcionario toEntity() {
        Funcionario f = new Funcionario();
        f.setId(this.id);
        f.setNome(this.nome);
        f.setEmail(this.email);
        f.setCargo(this.cargo);
        f.setDepartamento(this.departamento);
        f.setCpf(this.cpf);
        f.setStatus(this.status != null ? this.status : Funcionario.StatusFuncionario.ATIVO);
        return f;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCargo() { return cargo; }
    public void setCargo(String cargo) { this.cargo = cargo; }

    public String getDepartamento() { return departamento; }
    public void setDepartamento(String departamento) { this.departamento = departamento; }

    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public Funcionario.StatusFuncionario getStatus() { return status; }
    public void setStatus(Funcionario.StatusFuncionario status) { this.status = status; }
}
